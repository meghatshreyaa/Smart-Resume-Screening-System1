# 📄 Smart Resume Screening System

An academic BCA mini project that uses **Natural Language Processing (NLP)** and **Machine Learning** techniques to compare candidate resumes with a job description, calculate a similarity score, identify skills, and rank candidates.

## ✨ Features

- Upload multiple PDF resumes
- Enter a job description
- Extract text from resumes
- Text preprocessing
- Skill extraction
- TF-IDF vectorization
- Cosine similarity
- Resume match percentage
- Candidate ranking
- Shortlist / Review / Reject classification
- Candidate details
- Match-score chart
- CSV export
- Adjustable screening thresholds

## 🛠️ Technology Stack

- **Python**
- **Streamlit**
- **Pandas**
- **PyPDF2**
- **Scikit-learn**
- **TF-IDF**
- **Cosine Similarity**
- **NLP**

## 📂 Project Structure

```text
Smart-Resume-Screening-System/
│
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
│
├── data/
│   └── sample_job_description.txt
│
├── resumes/
│   └── .gitkeep
│
├── screenshots/
│   └── .gitkeep
│
└── docs/
    └── project_report.md
```

## ⚙️ Installation

### 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/Smart-Resume-Screening-System.git
cd Smart-Resume-Screening-System
```

### 2. Create a virtual environment (recommended)

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the application

```bash
streamlit run app.py
```

The application will open in your browser.

## 🧠 How the System Works

```text
Resume PDF
    ↓
PDF Text Extraction
    ↓
Text Preprocessing
    ↓
Skill Extraction
    ↓
TF-IDF Vectorization
    ↓
Cosine Similarity
    ↓
Match Score
    ↓
Candidate Ranking
    ↓
Shortlist / Review / Reject
```

## 📊 Screening Criteria

The default thresholds are:

| Match Score | Status |
|---:|---|
| 75% or above | ✅ Shortlist |
| 50% to 74.99% | ⚠️ Review |
| Below 50% | ❌ Reject |

The thresholds can be changed from the Streamlit sidebar.

## 🧮 Machine Learning Method

### TF-IDF

TF-IDF converts resume and job-description text into numerical vectors based on the importance of words in the documents.

### Cosine Similarity

Cosine similarity measures the similarity between the resume vector and the job-description vector.

The similarity is converted into a percentage and displayed as the **Match Score**.

## 📥 Input

- One or more text-based PDF resumes
- Job description

## 📤 Output

- Match score
- Candidate rank
- Matching skills
- Missing skills
- Screening status
- CSV report

## 🎓 Academic Use

This project is suitable for a **BCA mini project** and can be extended with:

- MySQL database
- Login and authentication
- Admin dashboard
- Candidate profile management
- Job-role selection
- Resume history
- Power BI dashboard
- Advanced NLP models
- Semantic embeddings

## ⚠️ Disclaimer

This project is intended for educational and demonstration purposes. The match score is based on text similarity and should **not** be used as the sole basis for real-world employment decisions.

## 👩‍💻 Author

**Shreya Meghat**

BCA Student
