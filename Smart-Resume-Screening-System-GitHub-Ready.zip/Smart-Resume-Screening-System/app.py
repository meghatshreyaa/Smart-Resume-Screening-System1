import re
import pandas as pd
import streamlit as st
from PyPDF2 import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


st.set_page_config(
    page_title="Smart Resume Screening System",
    page_icon="📄",
    layout="wide",
)


# -----------------------------
# Styling
# -----------------------------
st.markdown(
    """
    <style>
    .main-title {
        font-size: 40px;
        font-weight: 700;
        text-align: center;
        margin-bottom: 5px;
    }
    .subtitle {
        text-align: center;
        color: #666;
        margin-bottom: 25px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="main-title">📄 Smart Resume Screening System</div>',
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="subtitle">NLP-based resume matching and candidate ranking</div>',
    unsafe_allow_html=True,
)


# -----------------------------
# Skill dictionary
# -----------------------------
SKILLS = [
    "python", "java", "c", "c++", "c#", "sql", "mysql", "postgresql",
    "mongodb", "oracle", "html", "css", "javascript", "typescript",
    "react", "angular", "node.js", "flask", "django",
    "machine learning", "deep learning", "artificial intelligence",
    "data science", "data analysis", "natural language processing", "nlp",
    "pandas", "numpy", "scikit-learn", "tensorflow", "keras", "pytorch",
    "power bi", "tableau", "excel", "git", "github", "docker", "aws",
    "azure", "google cloud", "cloud computing", "communication",
    "leadership", "teamwork", "problem solving", "time management",
]


def extract_text_from_pdf(uploaded_file):
    """Extract text from a text-based PDF."""
    text = ""
    try:
        reader = PdfReader(uploaded_file)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    except Exception as exc:
        st.error(f"Could not read {uploaded_file.name}: {exc}")
    return text


def clean_text(text):
    """Normalize text for similarity calculation."""
    text = text.lower()
    text = re.sub(r"\S+@\S+", " ", text)
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"[^a-zA-Z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_skills(text):
    """Find skills from the predefined skill dictionary."""
    text = text.lower()
    found = []

    for skill in SKILLS:
        pattern = r"(?<!\w)" + re.escape(skill.lower()) + r"(?!\w)"
        if re.search(pattern, text):
            found.append(skill)

    return sorted(set(found))


def calculate_match_score(resume_text, job_description):
    """Calculate TF-IDF cosine similarity as a percentage."""
    resume = clean_text(resume_text)
    job = clean_text(job_description)

    if not resume or not job:
        return 0.0

    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
    )

    try:
        matrix = vectorizer.fit_transform([resume, job])
        score = cosine_similarity(matrix[0:1], matrix[1:2])[0][0] * 100
        return round(float(score), 2)
    except ValueError:
        return 0.0


def get_status(score, shortlist_threshold, review_threshold):
    if score >= shortlist_threshold:
        return "✅ Shortlist"
    if score >= review_threshold:
        return "⚠️ Review"
    return "❌ Reject"


# -----------------------------
# Sidebar settings
# -----------------------------
st.sidebar.header("⚙️ Screening Settings")

shortlist_threshold = st.sidebar.slider(
    "Shortlist threshold",
    min_value=50,
    max_value=90,
    value=75,
)

review_threshold = st.sidebar.slider(
    "Review threshold",
    min_value=30,
    max_value=70,
    value=50,
)

if review_threshold >= shortlist_threshold:
    st.sidebar.warning(
        "Review threshold should be lower than the shortlist threshold."
    )


# -----------------------------
# Inputs
# -----------------------------
st.subheader("💼 Job Description")

job_description = st.text_area(
    "Paste the job description below",
    height=220,
    placeholder=(
        "Example: Python Developer with Python, SQL, Machine Learning, "
        "Pandas, NumPy, Flask, Scikit-learn, Git and GitHub."
    ),
)

st.subheader("📂 Candidate Resumes")

uploaded_files = st.file_uploader(
    "Upload one or more PDF resumes",
    type=["pdf"],
    accept_multiple_files=True,
)

screen_button = st.button(
    "🔍 Screen Resumes",
    type="primary",
    use_container_width=True,
)


# -----------------------------
# Screening
# -----------------------------
if screen_button:
    if not job_description.strip():
        st.warning("Please enter a job description.")
        st.stop()

    if not uploaded_files:
        st.warning("Please upload at least one PDF resume.")
        st.stop()

    if review_threshold >= shortlist_threshold:
        st.error("Please set the review threshold below the shortlist threshold.")
        st.stop()

    results = []
    job_skills = extract_skills(job_description)
    progress = st.progress(0)
    status_text = st.empty()

    for index, uploaded_file in enumerate(uploaded_files):
        status_text.write(f"Analyzing {uploaded_file.name}...")

        resume_text = extract_text_from_pdf(uploaded_file)
        resume_skills = extract_skills(resume_text)

        matching_skills = sorted(set(resume_skills) & set(job_skills))
        missing_skills = sorted(set(job_skills) - set(resume_skills))

        score = calculate_match_score(resume_text, job_description)

        candidate_name = re.sub(
            r"\.pdf$",
            "",
            uploaded_file.name,
            flags=re.IGNORECASE,
        )

        results.append(
            {
                "Candidate": candidate_name,
                "Match Score (%)": score,
                "Status": get_status(
                    score,
                    shortlist_threshold,
                    review_threshold,
                ),
                "Matching Skills": ", ".join(matching_skills),
                "Missing Skills": ", ".join(missing_skills),
            }
        )

        progress.progress((index + 1) / len(uploaded_files))

    status_text.success("✅ Screening completed.")

    results_df = pd.DataFrame(results)
    results_df = results_df.sort_values(
        "Match Score (%)",
        ascending=False,
    ).reset_index(drop=True)

    results_df.insert(0, "Rank", range(1, len(results_df) + 1))

    # -----------------------------
    # Metrics
    # -----------------------------
    st.divider()
    st.subheader("📊 Screening Summary")

    total = len(results_df)
    shortlisted = (results_df["Status"] == "✅ Shortlist").sum()
    review = (results_df["Status"] == "⚠️ Review").sum()
    rejected = (results_df["Status"] == "❌ Reject").sum()
    average = results_df["Match Score (%)"].mean()

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("👥 Total", total)
    c2.metric("✅ Shortlisted", int(shortlisted))
    c3.metric("⚠️ Review", int(review))
    c4.metric("❌ Rejected", int(rejected))
    c5.metric("📈 Average Score", f"{average:.2f}%")

    # -----------------------------
    # Ranking table
    # -----------------------------
    st.divider()
    st.subheader("🏆 Candidate Ranking")

    st.dataframe(
        results_df,
        use_container_width=True,
        hide_index=True,
    )

    # -----------------------------
    # Top candidate
    # -----------------------------
    top = results_df.iloc[0]

    st.divider()
    st.subheader("🥇 Top Candidate")

    st.success(
        f"**{top['Candidate']}** | "
        f"Match Score: **{top['Match Score (%)']}%** | "
        f"Status: **{top['Status']}**"
    )

    if top["Matching Skills"]:
        st.write("**Matching skills:**", top["Matching Skills"])

    # -----------------------------
    # Candidate details
    # -----------------------------
    st.divider()
    st.subheader("🔎 Candidate Details")

    selected_candidate = st.selectbox(
        "Select a candidate",
        results_df["Candidate"].tolist(),
    )

    selected = results_df[
        results_df["Candidate"] == selected_candidate
    ].iloc[0]

    left, right = st.columns(2)

    with left:
        st.metric("Match Score", f"{selected['Match Score (%)']}%")
        st.write("**Status:**", selected["Status"])

        st.write("**Matching Skills**")
        if selected["Matching Skills"]:
            for skill in selected["Matching Skills"].split(", "):
                st.write(f"✅ {skill.title()}")
        else:
            st.write("No matching skills found.")

    with right:
        st.write("**Missing Skills**")
        if selected["Missing Skills"]:
            for skill in selected["Missing Skills"].split(", "):
                st.write(f"❌ {skill.title()}")
        else:
            st.write("No major missing skills.")

    # -----------------------------
    # Chart
    # -----------------------------
    st.divider()
    st.subheader("📈 Candidate Match Scores")

    chart_data = results_df.set_index("Candidate")[["Match Score (%)"]]
    st.bar_chart(chart_data)

    # -----------------------------
    # CSV download
    # -----------------------------
    st.divider()
    st.subheader("📥 Export Results")

    csv_data = results_df.to_csv(index=False).encode("utf-8")

    st.download_button(
        "⬇️ Download Screening Results (CSV)",
        data=csv_data,
        file_name="resume_screening_results.csv",
        mime="text/csv",
        use_container_width=True,
    )


st.divider()
st.caption(
    "Smart Resume Screening System | BCA Mini Project | "
    "Python • Streamlit • NLP • Scikit-learn"
)
