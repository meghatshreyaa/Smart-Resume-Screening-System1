# Smart Resume Screening System
## Mini Project Report

### 1. Introduction

The Smart Resume Screening System is a Python-based web application designed to assist with the initial screening of resumes. The application compares candidate resumes with a given job description and generates a similarity score.

### 2. Problem Statement

Manual resume screening can be time-consuming when a recruiter receives a large number of applications. The proposed system automates an initial text-based screening process by comparing resumes with job requirements.

### 3. Objectives

- Extract text from PDF resumes.
- Preprocess resume and job-description text.
- Identify relevant skills.
- Calculate resume-job similarity.
- Rank candidates.
- Classify candidates as Shortlist, Review, or Reject.
- Export screening results.

### 4. Technologies

- Python
- Streamlit
- Pandas
- PyPDF2
- Scikit-learn
- TF-IDF
- Cosine Similarity

### 5. Methodology

1. Recruiter enters a job description.
2. Recruiter uploads one or more PDF resumes.
3. Text is extracted from each resume.
4. Text is cleaned and normalized.
5. Skills are identified using a predefined skill dictionary.
6. Resume and job-description text are converted into TF-IDF vectors.
7. Cosine similarity is calculated.
8. Candidates are sorted by match score.
9. A screening status is assigned.
10. Results can be downloaded as CSV.

### 6. Modules

#### Module 1: Resume Upload
Allows the user to upload multiple PDF resumes.

#### Module 2: PDF Text Extraction
Uses PyPDF2 to extract text from text-based PDF files.

#### Module 3: Text Preprocessing
Converts text to lowercase and removes emails, URLs, special characters, and extra spaces.

#### Module 4: Skill Extraction
Searches for common technical and professional skills.

#### Module 5: Resume Matching
Uses TF-IDF and cosine similarity to calculate the similarity between the resume and job description.

#### Module 6: Candidate Ranking
Sorts candidates from highest to lowest match score.

#### Module 7: Screening Decision
Uses configurable thresholds:
- 75%+ = Shortlist
- 50%+ = Review
- Below 50% = Reject

#### Module 8: Reporting
Displays metrics, charts, candidate details, and CSV export.

### 7. Advantages

- Saves initial screening time.
- Can process multiple resumes.
- Provides consistent text-based scoring.
- Easy to use.
- Suitable for academic demonstration.
- Results can be exported.

### 8. Limitations

- Text-based similarity does not fully understand candidate quality.
- Scanned/image-only PDFs may not produce extractable text.
- The predefined skill dictionary is limited.
- The score should not be treated as a hiring decision.

### 9. Future Scope

- MySQL database integration.
- User authentication.
- Job-role database.
- Resume parsing for education and experience.
- Semantic embeddings and transformer models.
- Candidate profile management.
- Power BI dashboard.
- Cloud deployment.
- OCR for scanned resumes.

### 10. Conclusion

The Smart Resume Screening System demonstrates how NLP and machine learning techniques can be used to automate an initial resume screening workflow. It provides resume-job similarity scores, skill comparison, candidate ranking, and downloadable reports through a Streamlit interface.
